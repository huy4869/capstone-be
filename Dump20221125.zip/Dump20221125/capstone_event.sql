-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EventName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `EventLogo` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventDescript` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventLink` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventStatus` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'Ăn nhậu','nhau.logo','Team đi ăn nhậu','nhau.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(2,'Cắm trại','camtrai.logo','Team đi cắm trại ','cam.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(3,'Đi du lịch','dulich.logo','Team đi du lịch','camtrai.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(4,'Team building','building.logo','Team building lên Mộc Châu','building.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(5,'Đi câu cá Thủ Lệ','event.logo','Câu cá ở hồ câu Thủ Lệ','event.link',1,'2022-10-22 15:34:05.957827','2022-10-22 15:34:05.957854'),(6,'Đi câu cá sông Hồng','event.logo','Câu cá ở sông Hồng','event.link',1,'2022-10-22 15:36:07.167356','2022-10-22 15:36:07.167411'),(7,'Đi câu cá Hồ Tây','event.logo','Câu cá ở Hồ Tây','event.link',1,'2022-10-22 15:38:02.951338','2022-10-22 15:38:02.951371'),(8,'Đi xem phim Bố Già','event.logo','Xem phim Bố Già ở rạp Quốc Gia','event.link',1,'2022-10-22 17:41:35.009576','2022-10-22 17:41:35.009599'),(9,'Đi xem phim Lật Mặt','event.logo','Xem suất đêm CGV','event.link',1,'2022-10-23 19:44:14.980730','2022-10-23 19:44:14.980772'),(10,'Cắm trại ở Camping  Đồng Mô','camtrai.logo','Cắm trại trên Đồng Mô ','cam.com',1,'2022-10-26 15:27:25.495004','2022-10-26 15:27:25.495033'),(11,'Cắm trại ở Công viên Yên sở','camtrai.logo','Cắm trại trên Yên Sở','cam.com',1,'2022-10-26 15:35:17.576087','2022-10-26 15:35:17.576132'),(12,'Cắm trại trên núi Hàm Lợn','camtrai.logo','Cắm trại trên núi Hàm Lợn','/group?id=12',1,'2022-10-28 22:30:26.756614','2022-10-28 22:30:26.756642'),(13,'Cắm trại ở khu du lich Thiên Phú Lâm','camtrai.logo','Cắm trại ở khu du lich Thiên Phú Lâm','/group?id=13',1,'2022-10-28 22:43:20.553741','2022-10-28 22:43:20.553766'),(14,'Cắm trại ở Núi Trầm','camtrai.logo','Cắm trại ở Núi Trầm','/EventId=14',1,'2022-10-28 22:58:33.406669','2022-10-28 22:58:33.406696'),(15,'Cắm trại vườn quốc gia Ba Vì','camtrai.logo','Cắm trại vườn quốc gia Ba Vì','/EventId=15',1,'2022-10-30 19:05:18.330915','2022-10-30 19:05:18.330918'),(16,'Cắm trại ở Hồ Quan Sơn','camtrai.logo','Cắm trại ở Hồ Quan Sơn','/EventId=16',1,'2022-11-02 16:57:15.015571','2022-11-02 16:57:15.015596'),(17,'Cắm trại ở Hồ Đại Lải','camtrai.logo','Cắm trại ở Hồ Đại Lải','/EventId=17',1,'2022-11-02 16:57:51.488400','2022-11-02 16:57:51.488403'),(18,'Cắm trại ở Hồ Yên Trung','camtrai.logo','Cắm trại ở Hồ Yên Trung','/EventId=18',1,'2022-11-02 16:59:36.035816','2022-11-02 16:59:36.035819'),(19,'Tham quan làng cổ Đường Lâm','camtrai.logo','Tham quan làng cổ Đường Lâm','/EventId=19',1,'2022-11-02 16:59:40.139258','2022-11-02 16:59:40.139261'),(20,'Tham quan vườn Cúc Phương','','Tham quan vườn Cúc Phương','/EventId=20',1,'2022-11-02 17:03:05.017519','2022-11-02 17:03:05.017524'),(21,'Party tại Vịnh Hạ Long','','Party tại Vịnh Hạ Long','/EventId=21',1,'2022-11-02 17:03:56.846204','2022-11-02 17:03:56.846207'),(22,'Đi uống bia Tạ Hiện','logo','Mấy anh em lên Tạ Hiện liên hoan','/event/join/eventId=22',1,'2022-11-13 15:37:58.924515','2022-11-13 15:37:58.924541'),(23,'xinday','','1234','/event/join/eventId=23',1,'2022-11-23 17:19:04.286336','2022-11-23 17:19:04.286376'),(24,'hjghj','','bhvgvg','/event/join/eventId=24',1,'2022-11-23 17:25:43.708070','2022-11-23 17:25:43.708076');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 20:20:06
