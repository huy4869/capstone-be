-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: bwallet-database.ctw4jrxhi5cw.ap-southeast-1.rds.amazonaws.com    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `eventuser`
--

DROP TABLE IF EXISTS `eventuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventuser` (
  `UserID` int NOT NULL DEFAULT '0',
  `EventID` int NOT NULL DEFAULT '0',
  `UserRole` int NOT NULL,
  PRIMARY KEY (`EventID`,`UserID`),
  CONSTRAINT `FK_EventUser_Event_EventID` FOREIGN KEY (`EventID`) REFERENCES `event` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventuser`
--

LOCK TABLES `eventuser` WRITE;
/*!40000 ALTER TABLE `eventuser` DISABLE KEYS */;
INSERT INTO `eventuser` VALUES (1,1,1),(3,1,0),(4,1,0),(5,1,0),(6,1,0),(7,1,3),(8,1,0),(9,1,0),(10,1,0),(11,1,0),(12,1,0),(1,2,0),(11,2,1),(11,3,1),(3,4,1),(11,4,0),(12,4,0),(7,5,0),(9,5,1),(11,5,0),(11,6,1),(9,8,1),(10,8,0),(11,8,0),(1,9,0),(3,9,0),(4,9,0),(5,9,0),(6,9,0),(7,9,0),(8,9,0),(9,9,2),(10,9,0),(11,9,1),(12,9,0),(5,11,0),(9,11,1),(11,11,0),(5,12,0),(7,12,1),(5,13,0),(7,13,1),(5,14,0),(7,14,1),(11,14,0),(5,15,0),(7,15,1),(5,16,0),(7,16,1),(5,17,0),(7,17,1),(5,18,0),(7,18,1),(12,18,0),(5,19,0),(7,19,1),(12,19,4),(5,20,0),(7,20,1),(1,22,1),(3,22,0),(5,22,0),(7,22,0),(9,22,0),(3,23,1),(5,23,0),(11,23,0),(3,24,1),(5,24,0),(1,25,1),(8,25,2),(11,25,2),(1,26,1),(8,26,2),(11,26,2),(1,27,1),(8,27,2),(11,27,2),(6,31,0),(11,31,1),(12,31,0),(12,32,1),(1,33,0),(2,33,0),(12,33,1),(1,34,0),(2,34,0),(12,34,1),(11,35,2),(12,35,1),(12,36,1),(12,37,1),(12,38,1),(12,39,1),(1,40,1),(12,41,1),(1,42,1),(3,42,0),(6,42,0),(9,42,0),(10,42,0),(1,43,1),(6,43,0),(9,43,0),(10,43,0),(4,44,2),(12,44,1),(12,45,1),(1,46,1),(9,46,0),(10,46,0),(1,47,1),(9,47,0),(10,47,0),(1,48,1),(9,48,0),(10,48,0),(12,49,1),(1,50,1),(1,51,1),(9,51,0),(10,51,0),(15,51,0),(1,52,1),(15,52,0),(1,53,1),(12,53,0),(15,53,0),(1,54,1),(9,54,0),(10,54,0),(12,54,0),(15,54,4),(1,55,1),(1,56,1),(15,56,0),(4,57,0),(5,57,4),(7,57,4),(16,57,1),(1,58,1),(15,58,4),(1,59,1),(15,59,0),(1,60,1),(15,60,0),(1,61,4),(12,61,1),(1,62,1),(9,62,0),(10,62,0),(12,62,4),(15,62,0),(1,63,0),(12,63,1),(5,64,0),(6,64,1),(7,64,0),(1,65,0),(12,65,1),(5,66,0),(6,66,1),(7,66,0),(16,66,0),(1,67,0),(12,67,1),(12,68,1),(1,69,1),(12,69,0),(15,69,0),(12,70,1),(1,71,1),(12,71,0),(15,71,0),(1,72,0),(12,72,1),(1,73,1),(9,73,0),(10,73,0),(12,73,0),(15,73,0),(1,74,1),(9,74,0),(10,74,0),(12,74,0),(15,74,0),(1,75,1),(9,75,0),(10,75,2),(12,75,0),(15,75,0),(1,76,1),(9,76,0),(10,76,4),(12,76,0),(15,76,0),(1,77,1),(9,77,0),(12,77,4),(15,77,0),(1,78,1),(15,78,4),(12,79,1);
/*!40000 ALTER TABLE `eventuser` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-23 14:02:36
