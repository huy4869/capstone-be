-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: bwallet-database.ctw4jrxhi5cw.ap-southeast-1.rds.amazonaws.com    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EventName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `EventLogo` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventDescript` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventLink` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventStatus` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'Ăn nhậu tha','nhau.logo','Team đi ăn nhậu','nhau.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(2,'Cắm trại','camtrai.logo','Team đi cắm trại ','cam.com',0,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(3,'Đi du lịch','dulich.logo','Team đi du lịch','camtrai.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(4,'Team building','building.logo','Team building lên Mộc Châu','building.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(5,'Đi câu cá Thủ Lệ','event.logo','Câu cá ở hồ câu Thủ Lệ','event.link',1,'2022-10-22 15:34:05.957827','2022-10-22 15:34:05.957854'),(6,'Đi câu cá sông Hồng','event.logo','Câu cá ở sông Hồng','event.link',1,'2022-10-22 15:36:07.167356','2022-10-22 15:36:07.167411'),(7,'Đi câu cá Hồ Tây','event.logo','Câu cá ở Hồ Tây','event.link',1,'2022-10-22 15:38:02.951338','2022-10-22 15:38:02.951371'),(8,'Đi xem phim Bố Già','event.logo','Xem phim Bố Già ở rạp Quốc Gia','event.link',1,'2022-10-22 17:41:35.009576','2022-10-22 17:41:35.009599'),(9,'Đi xem phim Lật Mặt','event.logo','Xem suất đêm CGV','event.link',1,'2022-10-23 19:44:14.980730','2022-10-23 19:44:14.980772'),(10,'Cắm trại ở Camping  Đồng Mô','camtrai.logo','Cắm trại trên Đồng Mô ','cam.com',1,'2022-10-26 15:27:25.495004','2022-10-26 15:27:25.495033'),(11,'Cắm trại ở Công viên Yên sở','camtrai.logo','Cắm trại trên Yên Sở','cam.com',1,'2022-10-26 15:35:17.576087','2022-10-26 15:35:17.576132'),(12,'Cắm trại trên núi Hàm Lợn','camtrai.logo','Cắm trại trên núi Hàm Lợn','/group?id=12',1,'2022-10-28 22:30:26.756614','2022-10-28 22:30:26.756642'),(13,'Cắm trại ở khu du lich Thiên Phú Lâm','camtrai.logo','Cắm trại ở khu du lich Thiên Phú Lâm','/group?id=13',1,'2022-10-28 22:43:20.553741','2022-10-28 22:43:20.553766'),(14,'Cắm trại ở Núi Trầm','camtrai.logo','Cắm trại ở Núi Trầm','/EventId=14',1,'2022-10-28 22:58:33.406669','2022-10-28 22:58:33.406696'),(15,'Cắm trại vườn quốc gia Ba Vì','camtrai.logo','Cắm trại vườn quốc gia Ba Vì','/EventId=15',1,'2022-10-30 19:05:18.330915','2022-10-30 19:05:18.330918'),(16,'Cắm trại ở Hồ Quan Sơn','camtrai.logo','Cắm trại ở Hồ Quan Sơn','/EventId=16',1,'2022-11-02 16:57:15.015571','2022-11-02 16:57:15.015596'),(17,'Cắm trại ở Hồ Đại Lải','camtrai.logo','Cắm trại ở Hồ Đại Lải','/EventId=17',1,'2022-11-02 16:57:51.488400','2022-11-02 16:57:51.488403'),(18,'Cắm trại ở Hồ Yên Trung','camtrai.logo','Cắm trại ở Hồ Yên Trung','/EventId=18',1,'2022-11-02 16:59:36.035816','2022-11-02 16:59:36.035819'),(19,'Tham quan làng cổ Đường Lâm','camtrai.logo','Tham quan làng cổ Đường Lâm','/EventId=19',1,'2022-11-02 16:59:40.139258','2022-11-02 16:59:40.139261'),(20,'Tham quan vườn Cúc Phương','','Tham quan vườn Cúc Phương','/EventId=20',1,'2022-11-02 17:03:05.017519','2022-11-02 17:03:05.017524'),(21,'Party tại Vịnh Hạ Long','','Party tại Vịnh Hạ Long','/EventId=21',1,'2022-11-02 17:03:56.846204','2022-11-02 17:03:56.846207'),(22,'Đi uống bia Tạ Hiện','logo','Mấy anh em lên Tạ Hiện liên hoan','/event/join/eventId=22',1,'2022-11-13 15:37:58.924515','2022-11-13 15:37:58.924541'),(23,'Đi shopping trên Nghĩa Tân','','3 chị em đi mua đồ ở chợ Nghĩa Tân','/event/join/eventId=23',1,'2022-11-23 17:19:04.286336','2022-11-23 17:19:04.286376'),(24,'hjghj','','bhvgvg','/event/join/eventId=24',1,'2022-11-23 17:25:43.708070','2022-11-23 17:25:43.708076'),(25,'Test thử event','logooo','Test','/event/join/eventId=25',1,'2022-12-06 20:15:20.685598','2022-12-06 20:15:20.685598'),(26,'Test thử event 2',NULL,'Test','/event/join/eventId=26',1,'2022-12-06 20:17:32.515547','2022-12-06 20:17:32.515547'),(27,'Test thử event 2',NULL,'Test','/event/join/eventId=27',1,'2022-12-06 20:20:47.590170','2022-12-06 20:20:47.590170'),(31,'Du lịch Tam Đảo',NULL,'Ra Tam Đảo tham quan 4 ngày','/event/join/eventId=31',1,'2022-12-06 21:06:13.086020','2022-12-06 21:06:13.086020'),(32,'Leo núi Phú Sĩ','logo','Sang Nhật du lịch 5 ngày',NULL,1,'2022-12-13 08:23:41.589294','2022-12-13 08:23:41.589294'),(33,'Leo núi Phú Sĩ','logo','Sang Nhật du lịch 5 ngày',NULL,1,'2022-12-13 08:23:52.401477','2022-12-13 08:23:52.401477'),(34,'Leo núi Phú Sĩ',NULL,'Sang Nhật du lịch 5 ngày',NULL,1,'2022-12-13 08:24:21.828442','2022-12-13 08:24:21.828442'),(35,'Leo núi Phú Sĩ','logo','Sang Nhật du lịch 5 ngày',NULL,1,'2022-12-13 08:24:26.679831','2022-12-13 08:24:26.679831'),(36,'Leo núi Phú Sĩ a','logo','Sang Nhật du lịch 5 ngày',NULL,1,'2022-12-13 08:24:36.098842','2022-12-13 08:24:36.098842'),(37,'Đi Sầm Sơn','logo','Đi nghỉ mát 4 ngày',NULL,1,'2022-12-13 13:06:31.556890','2022-12-13 13:06:31.556890'),(38,'Lên Lạng Sơn','logo','Lên Lạng Sơn thăm nhà bà con',NULL,1,'2022-12-13 13:53:04.395188','2022-12-13 13:53:04.395188'),(39,'Lên Lạng Sơn 2','logo','Lên Lạng Sơn thăm nhà bà con',NULL,1,'2022-12-13 13:56:27.660261','2022-12-13 13:56:27.660261'),(40,'Lên Lạng Sơn 2','logo','Lên Lạng Sơn thăm nhà bà con','/event/join/eventId=OYdDBRQDpas7bg6o1lN9UQ==',1,'2022-12-13 14:19:22.987948','2022-12-13 14:19:22.987948'),(41,'Lên Lạng Sơn 3','logo','Lên Lạng Sơn thăm nhà bà con','/event/join/eventId=9CoS8lwMO3mxRVf9lu0/5w==',1,'2022-12-13 14:20:21.821527','2022-12-13 14:20:21.821527'),(42,'gfhfghgf','','fghfgh','/event/join/eventId=fPutd0DiYEKAg6CeotqUig==',1,'2022-12-17 21:35:40.198616','2022-12-17 21:35:40.198616'),(43,'Mới nhất','','mới nhất','/event/join?eventId=J0nCeG1/NQt51+8t+EeMJQ==',1,'2022-12-17 23:08:53.251007','2022-12-17 23:08:53.251007'),(44,'1234','','','/event/join?eventId=P4laabSTtzmldww0XXz4Dw==',1,'2022-12-18 12:07:32.215128','2022-12-18 12:07:32.215128'),(45,'aaaaa','','','/event/join?eventId=zVH54wdUSMLOih5j1llpKA==',0,'2022-12-19 12:39:30.552732','2022-12-19 12:39:30.552732'),(46,'1234','','234','/event/join?eventId=takZEOrx0jziwVzCoKNwoA==',1,'2022-12-19 19:34:45.113566','2022-12-19 19:34:45.113566'),(47,'Đi chơi','','','/event/join?eventId=mbxu5uiMnnyEQA1m1ezwDw==',1,'2022-12-19 21:19:51.708565','2022-12-19 21:19:51.708565'),(48,'Test 920','','','/event/join?eventId=7/ONKiI9rRBn+Rglm4H5dw==',0,'2022-12-19 21:20:52.050885','2022-12-19 21:20:52.050885'),(49,'Lên Lạng Sơn 3','logo','Lên Lạng Sơn thăm nhà bà con','/event/join?eventId=0G3zfY1vyuTzEqmp0sI7RA==',1,'2022-12-19 21:21:39.510180','2022-12-19 21:21:39.510180'),(50,'Ăn cơm','','cơm','/event/join?eventId=a4ijK8W/yG77RIYuzfpiVw==',1,'2022-12-19 22:32:53.534213','2022-12-19 22:32:53.534213'),(51,'Cắm trại Hồ Tây','','','/event/join?eventId=m52/DtbF1E4gaF0OY6NIjA==',1,'2022-12-19 22:38:51.732733','2022-12-19 22:38:51.732733'),(52,'Đi chơi','','Test','/event/join?eventId=SaTzjJY1q95zY1JA0vDT8A==',1,'2022-12-20 14:02:39.399284','2022-12-20 14:02:39.399284'),(53,'Test Yêu cầu trả tiền','','','/event/join?eventId=B+2c5BnnLCl5wirkPRfS3A==',1,'2022-12-20 14:12:18.640803','2022-12-20 14:12:18.640803'),(54,'Đi Hải Phòng','','','/event/join?eventId=MxcTcgiF0zwBAwSE90b5mA==',1,'2022-12-20 15:47:11.127984','2022-12-20 15:47:11.127984'),(55,'Foodtour Hải Phòng','','','/event/join?eventId=/6zVxgSyp6UNQ3LXw+STAA==',1,'2022-12-20 15:49:05.492084','2022-12-20 15:49:05.492084'),(56,'Goto Hải Phòng','','','/event/join?eventId=Zdb8YYLHoxUXSL5N07dwSg==',1,'2022-12-20 16:19:54.275853','2022-12-20 16:19:54.275853'),(57,'nhóm anh long','','Kiện Long xem','/event/join?eventId=waZV4W1IInsLzadA0E2f4Q==',1,'2022-12-20 17:21:08.743050','2022-12-20 17:21:08.743050'),(58,'Nhảy dù','','','/event/join?eventId=F8oHaIPlao644Gn8VqTJIg==',1,'2022-12-20 21:26:42.156606','2022-12-20 21:26:42.156606'),(59,'Cắm trại','','','/event/join?eventId=xtdbL3S4wLARWyeIudzGyQ==',0,'2022-12-20 21:30:17.396999','2022-12-20 21:30:17.396999'),(60,'Test\\','','','/event/join?eventId=IPIHL0hOkR5pL8HSgu2cPg==',1,'2022-12-20 21:34:59.665399','2022-12-20 21:34:59.665399'),(61,'Mua laptop','','','/event/join?eventId=frNVXo6CHsFH30Riqlzsig==',1,'2022-12-20 21:50:22.631170','2022-12-20 21:50:22.631170'),(62,'1234','','','/event/join?eventId=mvdHhQTocu/wDldUovGodA==',1,'2022-12-21 00:45:32.061708','2022-12-21 00:45:32.061708'),(63,'1234','','1234','/event/join?eventId=wCeto/ClfwtOm/V2KnFQlw==',1,'2022-12-21 01:07:04.766327','2022-12-21 01:07:04.766327'),(64,'Cam trai 8',NULL,'Team di cam trai','/event/join?eventId=bMZgRXZHhGSbZOjZ97fOlA==',1,'2022-12-21 01:07:46.087010','2022-12-21 01:07:46.087010'),(65,'1234','','','/event/join?eventId=u+a8Q7MlU+rOytQGkPv/VA==',1,'2022-12-21 01:08:38.783056','2022-12-21 01:08:38.783056'),(66,'Cam trai 8',NULL,'Team di cam trai','/event/join?eventId=6y3TY4GseNPDN7yMrfqXKQ==',1,'2022-12-21 01:09:29.834562','2022-12-21 01:09:29.834562'),(67,'1234','','1234','/event/join?eventId=be72237OgWSHLZSm703nrQ==',1,'2022-12-21 01:09:58.509080','2022-12-21 01:09:58.509080'),(68,'ádf','','','/event/join?eventId=E6yE0hAX6YGRCzxpDpCXaQ==',1,'2022-12-21 01:12:49.074299','2022-12-21 01:12:49.074299'),(69,'Sự kiện chiều ngày 21/12','','','/event/join?eventId=v3PFYibs9Q3Y0jmzTzRqyw==',1,'2022-12-21 14:11:12.446962','2022-12-21 14:11:12.446962'),(70,'1234','','','/event/join?eventId=XjU+5TCfHPpyPmExdRou3A==',1,'2022-12-21 15:00:55.184669','2022-12-21 15:00:55.184669'),(71,'Sự kiện 2','','','/event/join?eventId=PY1wOC5BemTuHTZ/x3QxyA==',0,'2022-12-21 15:30:58.203356','2022-12-21 15:30:58.203356'),(72,'hi','','','/event/join?eventId=U+PY3G3DcZsmrbY9w0JklQ==',1,'2022-12-21 20:12:10.539141','2022-12-21 20:12:10.539141'),(73,'1234','','','/event/join?eventId=0KF6wZV+myQfb1vuk6462w==',0,'2022-12-21 20:12:59.761575','2022-12-21 20:12:59.761575'),(74,'4321','','','/event/join?eventId=8eCce/NSy4HL7hdd+QpXaQ==',0,'2022-12-21 20:13:43.454886','2022-12-21 20:13:43.454886'),(75,'1234','','','/event/join?eventId=H8QXhHqvAHa5wiSkVMNzag==',0,'2022-12-21 20:41:22.133402','2022-12-21 20:41:22.133402'),(76,'Test','','','/event/join?eventId=gW1BF/vEZm8YraytFlM6PQ==',0,'2022-12-21 21:17:01.399432','2022-12-21 21:17:01.399432'),(77,'Test 935','','hgjhghjghjghj','/event/join?eventId=YP8+GR0quy+HdGKoWf3Prw==',1,'2022-12-21 21:35:38.865087','2022-12-21 21:35:38.865087'),(78,'Đi leo núi','','qưeqư','/event/join?eventId=6FYqDWJFE1cCzRr4/mwkpQ==',0,'2022-12-21 21:42:34.140088','2022-12-21 21:42:34.140088'),(79,'123','','','/event/join?eventId=52jRI0+j4AVQN4Eden1opQ==',1,'2022-12-22 13:25:31.514850','2022-12-22 13:25:31.514850');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-23 14:02:46
