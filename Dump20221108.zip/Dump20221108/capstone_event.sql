-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EventName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `EventLogo` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventDescript` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventLink` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `EventStatus` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'An nhau','nhau.logo','Team di an nhau','nhau.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(2,'Cam trai','camtrai.logo','Team di cam trai','cam.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(3,'Di du lich','dulich.logo','Team di du lich','camtrai.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(4,'Team building','building.logo','Team building len Moc Chau','building.com',1,'2022-10-16 00:00:00.000000','2022-10-16 00:00:00.000000'),(5,'Di cau ca','event.logo','Cau ca trong 3 ngay o Lang Son','event.link',1,'2022-10-22 15:34:05.957827','2022-10-22 15:34:05.957854'),(6,'Di cau ca','event.logo','Cau ca trong 4 ngay o Lang Son','event.link',1,'2022-10-22 15:36:07.167356','2022-10-22 15:36:07.167411'),(7,'Di cau ca','event.logo','Cau ca trong 4 ngay o Lang Son','event.link',1,'2022-10-22 15:38:02.951338','2022-10-22 15:38:02.951371'),(8,'Di xem phim','event.logo','Xem phim Bo Gia o rap Quoc Gia','event.link',1,'2022-10-22 17:41:35.009576','2022-10-22 17:41:35.009599'),(9,'Di xem phim Lat Mat','event.logo','Xem phim o rap CGV','event.link',1,'2022-10-23 19:44:14.980730','2022-10-23 19:44:14.980772'),(10,'Cam trai 2','camtrai.logo','Team di cam trai','cam.com',1,'2022-10-26 15:27:25.495004','2022-10-26 15:27:25.495033'),(11,'Cam trai 2','camtrai.logo','Team di cam trai','cam.com',1,'2022-10-26 15:35:17.576087','2022-10-26 15:35:17.576132'),(12,'Cam trai 5','camtrai.logo','Team di cam trai','/group?id=12',1,'2022-10-28 22:30:26.756614','2022-10-28 22:30:26.756642'),(13,'Cam trai 6','camtrai.logo','Team di cam trai','/group?id=13',1,'2022-10-28 22:43:20.553741','2022-10-28 22:43:20.553766'),(14,'Cam trai 7','camtrai.logo','Team di cam trai','/EventId=14',1,'2022-10-28 22:58:33.406669','2022-10-28 22:58:33.406696'),(15,'Cam trai 8','camtrai.logo','Team di cam trai','/EventId=15',1,'2022-10-30 19:05:18.330915','2022-10-30 19:05:18.330918'),(16,'Cam trai 10','camtrai.logo','Team di cam trai','/EventId=16',1,'2022-11-02 16:57:15.015571','2022-11-02 16:57:15.015596'),(17,'Cam trai 11','camtrai.logo','Team di cam trai','/EventId=17',1,'2022-11-02 16:57:51.488400','2022-11-02 16:57:51.488403'),(18,'Cam trai 11','camtrai.logo','Team di cam trai','/EventId=18',1,'2022-11-02 16:59:36.035816','2022-11-02 16:59:36.035819'),(19,'Cam trai 11','camtrai.logo','Team di cam trai','/EventId=19',1,'2022-11-02 16:59:40.139258','2022-11-02 16:59:40.139261'),(20,'Cam trai 12','','Team di cam trai','/EventId=20',1,'2022-11-02 17:03:05.017519','2022-11-02 17:03:05.017524'),(21,'Cam trai 12','','Team di cam trai','/EventId=21',1,'2022-11-02 17:03:56.846204','2022-11-02 17:03:56.846207');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-08 15:26:26
