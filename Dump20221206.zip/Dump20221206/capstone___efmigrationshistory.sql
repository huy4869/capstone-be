-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__efmigrationshistory`
--

DROP TABLE IF EXISTS `__efmigrationshistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__efmigrationshistory` (
  `MigrationId` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__efmigrationshistory`
--

LOCK TABLES `__efmigrationshistory` WRITE;
/*!40000 ALTER TABLE `__efmigrationshistory` DISABLE KEYS */;
INSERT INTO `__efmigrationshistory` VALUES ('20220929081349_Create2Table','5.0.10'),('20220929092840_IdAutoIncrease','5.0.10'),('20221003112611_Add_Date_AccountStatus_Column','5.0.10'),('20221003141658_Add_Otp','5.0.10'),('20221003142143_Add_AutoIncrease_Otp','5.0.10'),('20221003144931_Add_Otp_Again','5.0.10'),('20221012040156_Add_Event','5.0.10'),('20221016091513_AddEventUser','5.0.10'),('20221016112821_UpdatePrimaryKeyEvenUserTable','5.0.10'),('20221021150003_Add_Friend','5.0.10'),('20221022040045_Update','5.0.10'),('20221022072116_DeleteColumnFriend','5.0.10'),('20221022075450_UpdateEventUser','5.0.10'),('20221022124922_Add_Receipts_UserDepts','5.0.10'),('20221026081152_CreateReceipt','5.0.10'),('20221026085814_AddAvatarUser','5.0.10'),('20221028152710_DeleteRequireEventLink','5.0.10'),('20221029143359_UpdateUser','5.0.10'),('20221030120037_DeleteAllRequired','5.0.10'),('20221030140207_Check','5.0.10'),('20221030155049_DeleteDivideTypeInReceipt','5.0.10'),('20221101141747_CreatePaid','5.0.10'),('20221101150853_Create2PaidTable','5.0.10'),('20221101151423_Create2PaidTable2','5.0.10'),('20221114073451_AddRequest','5.0.10'),('20221123064853_AddProofImage','5.0.10'),('20221124103158_CreateInvite','5.0.10'),('20221125041437_UpdateReceipt','5.0.10'),('20221125093416_UpdatePaidDept','5.0.10'),('20221125100318_UpdateUser','5.0.10'),('20221128072805_addCodePaidDebt','5.0.10'),('20221128084242_UpdateFriend','5.0.10'),('20221128154810_addTypePaidDebt','5.0.10'),('20221129120252_AddUserSetting','5.0.10'),('20221201101300_addFAQ','5.0.10');
/*!40000 ALTER TABLE `__efmigrationshistory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-06 13:22:33
